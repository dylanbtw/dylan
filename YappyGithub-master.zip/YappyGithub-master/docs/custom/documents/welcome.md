<p align="center">
  <a href="https://datitisev.github.io/DiscordBot-Yappy">
    <img alt="Github Events w/o webhooks" src="https://u.pomf.is/jzajwy.png" width="546"><br />
    <img alt="Github Events w/ webhooks" src="https://u.pomf.is/vurxay.png" width="546"><br />
  </a>
</p>

[![Online Users in Yappy Discord Server](https://discordapp.com/api/guilds/231548941492027393/embed.png)](https://discord.gg/HHqndMG)
[![Yappy: David (Dependencies status)](https://img.shields.io/david/datitisev/DiscordBot-Yappy.svg?maxAge=2592000)](https://david-dm.org/datitisev/DiscordBot-Yappy)
[![Yappy: Codacy Badge](https://api.codacy.com/project/badge/Grade/950ed41fd5b6417d9cc83f332d93e0ef)](https://www.codacy.com/app/datiti/DiscordBot-Yappy?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=datitisev/DiscordBot-Yappy&amp;utm_campaign=Badge_Grade)

Yappy monitors your Github repos and pushes events to one or multiple Discord channel(s)!

# Welcome!
Welcome to Yappy's documentation. See the FAQ for help. Create an issue on Github or talk to us in our official discord server if you have an issue or want to recommend something for the bot or the documentation.

## Usage
... to be written ...

## Help
If you don't understand something in the documentation, you are experiencing problems, or you just need a gentle
nudge in the right direction, please don't hesitate to join our official [Yappy Server](https://discord.gg/HHqndMG).
